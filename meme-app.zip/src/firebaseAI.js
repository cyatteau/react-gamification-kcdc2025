import { getAI, getGenerativeModel, GoogleAIBackend } from "firebase/ai";
import { firebaseApp } from "./firebase";

const ai = getAI(firebaseApp, { backend: new GoogleAIBackend() });

const generationConfig = {
  temperature: 1.2,
  topP: 0.95,
  maxOutputTokens: 100,
};

export const memeModel = getGenerativeModel(ai, {
  model: "gemini-2.5-flash-lite",
  generationConfig,
});
