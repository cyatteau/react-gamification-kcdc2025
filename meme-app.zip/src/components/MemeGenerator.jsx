/* MemeGenerator.jsx */
import React, { useState, useEffect } from "react";
import confetti from "canvas-confetti";
import { memeModel } from "../firebaseAI";
import { auth } from "../firebase";
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  query,
  where,
  getDocs,
  onSnapshot,
} from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";

const db = getFirestore();
const banned = ["fuck", "shit", "damn", "bitch", "asshole", "bastard"];
const profane = new RegExp(`\\b(${banned.join("|")})\\b`, "i");

export default function MemeGenerator({ getImageDataUrl }) {
  const [submitted, setSubmitted] = useState(
    Boolean(localStorage.getItem("meme_submitted"))
  );
  const [options, setOptions] = useState([]);
  const [picked, setPicked] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let stopSnap = () => {};
    const stopAuth = onAuthStateChanged(auth, (user) => {
      stopSnap();
      if (!user) return;
      const ref = doc(db, "memes", user.uid);
      stopSnap = onSnapshot(ref, (snap) => {
        const exists = snap.exists();
        if (exists) {
          localStorage.setItem("meme_submitted", "true");
        } else {
          localStorage.removeItem("meme_submitted");
        }
        setSubmitted(exists);
      });
    });
    return () => {
      stopSnap();
      stopAuth();
    };
  }, []);

  const fetchCaption = async (base64) => {
    const salt = crypto.randomUUID();
    const prompt = [
      "You are a viral meme copywriter.",
      "Return ONE short caption that fits the drawing well.",
      "No hashtags, no marketing fluff; be funny and witty, a bit absurd, but family-friendly.",
      `Secret salt: ${salt}. Do NOT reveal or reference the salt.`
    ].join(" ");

    const { response } = await memeModel.generateContent(
      [
        { text: prompt },
        { inlineData: { mimeType: "image/png", data: base64 } },
      ],
      { generationConfig: { temperature: 1.2, topP: 0.9, topK: 40 } }
    );
    const text = (await response.text()).trim();

    if (profane.test(text)) throw new Error("Generated profanity");

    const dup = await getDocs(
      query(collection(db, "memes"), where("caption", "==", text))
    );
    if (!dup.empty) throw new Error("Try again");

    return text;
  };

  const startGeneration = async () => {
    setError("");
    setIsLoading(true);
    confetti({ particleCount: 30, spread: 40, origin: { y: 0.6 } });

    const base64 = getImageDataUrl().replace(/^data:image\/png;base64,/, "");
    try {
      const [a, b] = await Promise.all([
        fetchCaption(base64),
        fetchCaption(base64),
      ]);
      setOptions([a, b]);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const pickAndSubmit = async (caption) => {
    const uid = auth.currentUser.uid;
    setPicked(caption);

    try {
      await setDoc(
        doc(db, "memes", uid),
        {
          drawingUrl: getImageDataUrl(),
          caption,
          votes: 0,
          ownerUid: uid,
          published: false,
          ts: Date.now(),
        },
        { merge: false }
      );

      localStorage.setItem("meme_submitted", "true");
      setSubmitted(true);
    } catch (err) {
      console.warn(err);
      setSubmitted(true);
    }
  };

  if (submitted)
    return (
      <div style={{ marginTop: 10 }}>You’ve already submitted a meme ✔️</div>
    );
  if (picked)
    return <div style={{ marginTop: 10 }}>Submitted: “{picked}” ✔️</div>;

  return (
    <div>
      {options.length === 0 ? (
        <button
          className="button"
          disabled={isLoading}
          onClick={startGeneration}
        >
          {isLoading ? "Generating…" : "Generate 2 Captions"}
        </button>
      ) : (
        <div style={{ display: "flex", gap: "1rem", marginTop: "1rem" }}>
          {options.map((opt, i) => (
            <button
              key={i}
              className="button caption-choice"
              onClick={() => pickAndSubmit(opt)}
            >
              {opt}
            </button>
          ))}
        </div>
      )}
      {error && <div style={{ color: "red", marginTop: 8 }}>{error}</div>}
    </div>
  );
}
