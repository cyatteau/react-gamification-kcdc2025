/* MemeGenerator.jsx */
import React, { useState, useEffect, useCallback } from "react";
import confetti from "canvas-confetti";
import { memeModel } from "../firebaseAI";
import { auth } from "../firebase";
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  query,
  where,
  getDocs,
  onSnapshot,
} from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";

const db = getFirestore();
const banned = ["fuck", "shit", "damn", "bitch", "asshole", "bastard"];
const profane = new RegExp(`\\b(${banned.join("|")})\\b`, "i");

// Utility: keep captions tidy for the buttons/cards
const clamp = (s, n = 120) => (s.length > n ? s.slice(0, n - 1) + "…" : s);

export default function MemeGenerator({ getImageDataUrl, onSubmitted }) {
  const [submitted, setSubmitted] = useState(
    Boolean(localStorage.getItem("meme_submitted"))
  );
  const [options, setOptions] = useState([]);
  const [picked, setPicked] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  // auth + server-side submitted state
  useEffect(() => {
    let stopSnap = () => {};
    const stopAuth = onAuthStateChanged(auth, (user) => {
      stopSnap();
      if (!user) return;
      const ref = doc(db, "memes", user.uid);
      stopSnap = onSnapshot(ref, (snap) => {
        const exists = snap.exists();
        if (exists) {
          localStorage.setItem("meme_submitted", "true");
        } else {
          localStorage.removeItem("meme_submitted");
        }
        setSubmitted(exists);
      });
    });
    return () => {
      stopSnap();
      stopAuth();
    };
  }, []);

  const fetchCaption = async (base64) => {
    const salt = crypto.randomUUID();
    const prompt = [
      "You are a viral meme copywriter.",
      "Return ONE short caption that fits the drawing well.",
      "No hashtags, no marketing fluff; be funny and witty, a bit absurd, but family-friendly.",
      `Secret salt: ${salt}. Do NOT reveal or reference the salt.`,
    ].join(" ");

    const { response } = await memeModel.generateContent(
      [
        { text: prompt },
        { inlineData: { mimeType: "image/png", data: base64 } },
      ],
      { generationConfig: { temperature: 1.2, topP: 0.9, topK: 40 } }
    );
    const text = (await response.text()).trim();

    if (profane.test(text)) throw new Error("Generated profanity");

    const dup = await getDocs(
      query(collection(db, "memes"), where("caption", "==", text))
    );
    if (!dup.empty) throw new Error("Try again");

    return text;
  };

  const startGeneration = useCallback(async () => {
    if (isLoading) return;
    setError("");
    setIsLoading(true);
    confetti({ particleCount: 30, spread: 40, origin: { y: 0.6 } });

    const base64 = getImageDataUrl().replace(/^data:image\/png;base64,/, "");
    try {
      const [a, b] = await Promise.all([
        fetchCaption(base64),
        fetchCaption(base64),
      ]);
      setOptions([a, b]);
    } catch (err) {
      setError(err.message || "Could not generate captions");
    } finally {
      setIsLoading(false);
    }
  }, [getImageDataUrl, isLoading]);

  const pickAndSubmit = async (caption) => {
    if (!auth.currentUser) return;
    const uid = auth.currentUser.uid;
    setPicked(caption);

    try {
      await setDoc(
        doc(db, "memes", uid),
        {
          drawingUrl: getImageDataUrl(),
          caption,
          votes: 0,
          ownerUid: uid,
          published: false,
          ts: Date.now(),
        },
        { merge: false }
      );

      localStorage.setItem("meme_submitted", "true");
      setSubmitted(true);
      onSubmitted?.();
    } catch (err) {
      console.warn(err);
      setSubmitted(true);
      onSubmitted?.();
    }
  };

  // Keyboard: G to generate, 1/2 to choose, Enter picks first
  useEffect(() => {
    const onKey = (e) => {
      const k = e.key.toLowerCase();
      if (submitted || picked) return;

      if (!options.length && !isLoading && k === "g") startGeneration();
      if (options.length) {
        if (k === "1") pickAndSubmit(options[0]);
        if (k === "2") pickAndSubmit(options[1]);
        if (k === "enter") pickAndSubmit(options[0]);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [options, isLoading, submitted, picked, startGeneration]);

  if (submitted) {
    return (
      <div className="h-muted" style={{ marginTop: 10 }}>
        You’ve already submitted a meme ✔️
      </div>
    );
  }
  if (picked) {
    return (
      <div className="h-muted" style={{ marginTop: 10 }}>
        Submitted: “{picked}” ✔️
      </div>
    );
  }

  return (
    <div className="stack" aria-live="polite">
      {/* Primary action */}
      {!options.length && (
        <button
          type="button"
          className="btn btn-primary"
          onClick={startGeneration}
          disabled={isLoading}
          title="Generate two caption ideas (G)"
        >
          {isLoading ? "Generating…" : "Generate 2 Captions"}
        </button>
      )}

      {/* Loading skeletons */}
      {isLoading && (
        <div className="caption-grid">
          <div className="caption-card skeleton">
            <div className="skeleton-line" style={{ width: "80%" }} />
            <div className="skeleton-line" style={{ width: "60%" }} />
          </div>
          <div className="caption-card skeleton">
            <div className="skeleton-line" style={{ width: "70%" }} />
            <div className="skeleton-line" style={{ width: "50%" }} />
          </div>
        </div>
      )}

      {/* Options as caption cards */}
      {!!options.length && !isLoading && (
        <div className="caption-grid" role="list">
          {options.map((opt, i) => (
            <article className="caption-card card" role="listitem" key={i}>
              <p className="caption-text">{clamp(opt)}</p>
              <div className="row">
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={() => pickAndSubmit(opt)}
                  title={`Pick option ${i + 1} (${i + 1})`}
                >
                  Pick
                </button>
                <span className="kbd">{i + 1}</span>
              </div>
            </article>
          ))}
        </div>
      )}

      {/* Error alert */}
      {error && (
        <div className="alert" role="alert">
          {error}
          {error.toLowerCase().includes("profanity") && (
            <span className="h-muted" style={{ marginLeft: 8 }}>
              Try another drawing or click Generate again.
            </span>
          )}
        </div>
      )}
    </div>
  );
}
