import React, {
  forwardRef,
  useRef,
  useImperativeHandle,
  useEffect,
} from "react";

const CanvasDrawer = forwardRef(
  ({ brushColor = "#333", brushSize = 3, eraserMode = false }, ref) => {
    const canvasRef = useRef(null);
    const ctxRef = useRef(null);
    const drawing = useRef(false);

    const resizeCanvas = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;

      const rect = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;

      const desiredWidth = Math.round(rect.width * dpr);
      const desiredHeight = Math.round(rect.height * dpr);

      if (canvas.width === desiredWidth && canvas.height === desiredHeight)
        return;

      // Keep current image
      const ctx = canvas.getContext("2d");
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

      canvas.width = desiredWidth;
      canvas.height = desiredHeight;
      ctx.scale(dpr, dpr);
      ctx.lineCap = "round";
      ctxRef.current = ctx;
      applyBrush();

      try {
        ctx.putImageData(imageData, 0, 0);
      } catch (e) {
        // Safe to ignore if sizes changed a lot
        // console.warn("Could not restore image data after resize:", e);
      }
    };

    const applyBrush = () => {
      if (!ctxRef.current) return;
      ctxRef.current.strokeStyle = brushColor;
      ctxRef.current.lineWidth = brushSize;
      ctxRef.current.globalCompositeOperation = eraserMode
        ? "destination-out"
        : "source-over";
    };

    useEffect(() => {
      resizeCanvas();
      window.addEventListener("resize", resizeCanvas);
      return () => window.removeEventListener("resize", resizeCanvas);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(applyBrush, [brushColor, brushSize, eraserMode]);

    const getPos = (evt) => {
      const rect = canvasRef.current.getBoundingClientRect();
      return { x: evt.clientX - rect.left, y: evt.clientY - rect.top };
    };

    const start = (evt) => {
      const pos = getPos(evt);
      drawing.current = true;
      evt.target.setPointerCapture?.(evt.pointerId);
      ctxRef.current.beginPath();
      ctxRef.current.moveTo(pos.x, pos.y);
    };

    const move = (evt) => {
      if (!drawing.current) return;
      const pos = getPos(evt);
      ctxRef.current.lineTo(pos.x, pos.y);
      ctxRef.current.stroke();
      ctxRef.current.beginPath();
      ctxRef.current.moveTo(pos.x, pos.y);
    };

    const stop = (evt) => {
      drawing.current = false;
      ctxRef.current.beginPath();
      evt.target.releasePointerCapture?.(evt.pointerId);
    };

    useImperativeHandle(ref, () => ({
      getImageDataUrl: () => canvasRef.current?.toDataURL("image/png"),
      clear: () => {
        const canvas = canvasRef.current;
        const ctx = ctxRef.current;
        if (!canvas || !ctx) return;
        ctx.save();
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.restore();
      },
    }));

    return (
      <canvas
        ref={canvasRef}
        style={{ cursor: "crosshair", touchAction: "none", height: "480px" }}
        onPointerDown={start}
        onPointerMove={move}
        onPointerUp={stop}
        onPointerCancel={stop}
        onPointerLeave={stop}
      />
    );
  }
);

export default CanvasDrawer;
