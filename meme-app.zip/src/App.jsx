import React, { useEffect, useRef, useState } from "react";
import CanvasDrawer from "./components/CanvasDrawer";
import MemeGenerator from "./components/MemeGenerator";
import "./App.css";

import { firebaseApp } from "./firebase";
import { getAuth, signInAnonymously } from "firebase/auth";

const auth = getAuth(firebaseApp);

export default function App() {
  const canvasRef = useRef(null);

  const [hasSubmitted, setHasSubmitted] = useState(
    Boolean(localStorage.getItem("meme_submitted"))
  );

  const [brushColor, setBrushColor] = useState("#333");
  const [brushSize, setBrushSize] = useState(3);
  const [eraserMode, setEraserMode] = useState(false);

  const [toast, setToast] = useState(null);

  const toggleEraser = () => setEraserMode((prev) => !prev);
  const clearCanvas = () => canvasRef.current?.clear();

  useEffect(() => {
    signInAnonymously(auth).catch((err) =>
      console.warn("Anon sign-in failed:", err)
    );
  }, []);

  // Shortcuts: B brush, E eraser, X clear
  useEffect(() => {
    const onKey = (e) => {
      const k = e.key.toLowerCase();
      if (k === "b") setEraserMode(false);
      if (k === "e") setEraserMode(true);
      if (k === "x") clearCanvas();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const getImageDataUrl = () => canvasRef.current?.getImageDataUrl() || "";

  const handleSubmitted = () => {
    localStorage.setItem("meme_submitted", "true");
    setHasSubmitted(true);
    setToast({ text: "Submitted. Check the Meme Wall!" });
    setTimeout(() => setToast(null), 2200);
  };

  return (
    <div className="App">
      <header className="header card">
        <div className="brand">
          <div className="brand-badge">DM</div>
          <h1>Draw to Meme</h1>
        </div>
        <div className="header-actions">
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => window.location.assign("/meme-wall.html")}
          >
            Meme Wall
          </button>
        </div>
      </header>

      <section className="directions card" aria-labelledby="how-it-works">
        <p id="how-it-works" className="h-muted">
          How it works
        </p>
        <ol>
          <li>Sketch something in the canvas.</li>
          <li>
            Click <strong>Generate 2 Captions</strong>.
          </li>
          <li>
            Pick your favorite and <strong>Submit</strong>.
          </li>
        </ol>
      </section>

      <section className="layout">
        <div className="canvas-card card">
          <div className="canvas-shell">
            <div className="draw-area">
              <CanvasDrawer
                ref={canvasRef}
                brushColor={brushColor}
                brushSize={brushSize}
                eraserMode={eraserMode}
              />
            </div>

            {/* Toolbar overlay */}
            <div className="toolbar" role="toolbar" aria-label="Canvas tools">
              <button
                type="button"
                className="tool"
                aria-label="Brush"
                aria-pressed={!eraserMode}
                onClick={() => setEraserMode(false)}
                title="Brush (B)"
              >
                🖌️
              </button>
              <button
                type="button"
                className="tool"
                aria-label="Eraser"
                aria-pressed={eraserMode}
                onClick={() => setEraserMode(true)}
                title="Eraser (E)"
              >
                🧽
              </button>
              <button
                type="button"
                className="tool"
                aria-label="Clear canvas"
                onClick={clearCanvas}
                title="Clear (X)"
              >
                🧼
              </button>
            </div>
          </div>
        </div>

        <aside className="controls card" aria-labelledby="tools">
          <h3 id="tools" className="h-muted">
            Tools
          </h3>

          <div className="control-grid">
            <div className="field">
              <label htmlFor="brushColor">Brush color</label>
              <input
                id="brushColor"
                className="color"
                type="color"
                value={brushColor}
                onChange={(e) => {
                  setBrushColor(e.target.value);
                  setEraserMode(false);
                }}
                aria-label="Brush color"
              />
            </div>

            <div className="field">
              <label htmlFor="brushSize">
                Brush size <span className="kbd">{brushSize}px</span>
              </label>
              <input
                id="brushSize"
                className="range"
                type="range"
                min="1"
                max="20"
                value={brushSize}
                onChange={(e) => setBrushSize(Number(e.target.value))}
              />
            </div>

            <div className="field">
              <label htmlFor="modeBtn">Mode</label>
              <button
                id="modeBtn"
                type="button"
                className="btn btn-ghost"
                aria-pressed={eraserMode}
                onClick={toggleEraser}
              >
                {eraserMode ? "🧽 Brush off" : "🖌️ Brush on"}
              </button>
            </div>

            <div className="field">
              <label className="visually-hidden" htmlFor="clearBtn">
                Clear canvas
              </label>
              <button
                id="clearBtn"
                type="button"
                className="btn btn-ghost"
                onClick={clearCanvas}
              >
                🧼 Clear Canvas
              </button>
            </div>
          </div>
        </aside>
      </section>

      {/* Generator panel */}
      <section className="card" style={{ marginTop: "16px", padding: "16px" }}>
        <MemeGenerator
          getImageDataUrl={getImageDataUrl}
          onSubmitted={handleSubmitted}
        />
      </section>

      {toast && (
        <div className="toast" role="status" aria-live="polite">
          {toast.text}
        </div>
      )}
    </div>
  );
}
