import React, { useEffect, useRef, useState } from "react";
import CanvasDrawer from "./components/CanvasDrawer";
import MemeGenerator from "./components/MemeGenerator";
import "./App.css";

import { firebaseApp } from "./firebase";
import { getAuth, signInAnonymously } from "firebase/auth";

const auth = getAuth(firebaseApp);

export default function App() {
  const canvasRef = useRef(null);
  const [hasSubmitted, setHasSubmitted] = useState(
    Boolean(localStorage.getItem("meme_submitted"))
  );

  useEffect(() => {
    signInAnonymously(auth).catch((err) =>
      console.warn("Anon sign-in failed:", err)
    );
  }, []);

  const getImageDataUrl = () => canvasRef.current?.getImageDataUrl() || "";

  const handleSubmitted = () => {
    localStorage.setItem("meme_submitted", "true");
    setHasSubmitted(true);
  };

  return (
    <div className="App">
      <header className="hero">
        <h1>Draw-to-Meme Battle</h1>
        <p>Create → Laugh → Submit</p>
      </header>

      <div className="directions">
        <ol>
          <li>Sketch something fun in the canvas.</li>
          <li>
            Click <strong>Generate 2 Captions</strong>.
          </li>
          <li>
            Pick the wittiest line → <strong>Submit</strong>.
          </li>
          <li>Or jump straight to the meme wall anytime below.</li>
        </ol>
      </div>

      <div className="draw-area">
        <CanvasDrawer ref={canvasRef} />
      </div>

      <div className="controls">
        <MemeGenerator
          getImageDataUrl={getImageDataUrl}
          onSubmitted={handleSubmitted}
        />
      </div>

      {/* Meme Wall button always available */}
      <div style={{ marginTop: "2rem", textAlign: "center" }}>
        <button
          className="button"
          onClick={() =>
            window.location.assign(
              "https://draw-meme-app.vercel.app/meme-wall.html"
            )
          }
        >
          View Meme Wall
        </button>
      </div>
    </div>
  );
}
